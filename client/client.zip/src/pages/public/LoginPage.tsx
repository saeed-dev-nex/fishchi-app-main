import React, { useEffect, useRef, useState } from 'react';
import {
  Grid,
  Paper,
  TextField,
  Button,
  Typography,
  InputAdornment,
  IconButton,
  useTheme,
  useMediaQuery,
  Box,
  Avatar,
  Divider,
  Container,
  Alert,
  CircularProgress,
} from '@mui/material';
import {
  Visibility,
  VisibilityOff,
  Lock,
  Email,
  Person,
  Google,
  GitHub,
} from '@mui/icons-material';
import loginImage from '../../assets/images/login.jpg';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import type { AppDispatch, RootState } from '../../store';
import { useForm, type SubmitHandler } from 'react-hook-form';
import { loginSchema, type LoginFormInputs } from '../../types';
import { zodResolver } from '@hookform/resolvers/zod';
import { clearState, loginUser } from '../../store/features/authSlice';
import apiClient from '../../api/axios';

// No makeStyles needed in MUI v5, we'll use the `sx` prop.

const LoginPage: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const location = useLocation();
  const { isLoading, user, error } = useSelector(
    (state: RootState) => state.auth
  );
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormInputs>({
    resolver: zodResolver(loginSchema),
  });
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [showPassword, setShowPassword] = useState(false);
  // State to show a success message instead of redirecting
  const [officeLoginSuccess, setOfficeLoginSuccess] = useState(false);

  // Ref to hold the session ID from the URL
  const officeSessionId = useRef<string | null>(null);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  useEffect(() => {
    dispatch(clearState());
  }, [dispatch]);

  useEffect(() => {
    if (user) {
      // Redirect to the intended destination or dashboard
      const from = location.state?.from?.pathname || '/app';
      navigate(from, { replace: true });
    }
  }, [user, navigate, location.state]);
  // --- 3. Add this useEffect to read query params ONCE ---
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const from = searchParams.get('from');
    const sessionId = searchParams.get('session_id');

    if (from === 'office' && sessionId) {
      // Store the session ID if we're in the office flow
      officeSessionId.current = sessionId;
    }
  }, [location.search]); // Runs when URL changes

  // --- 4. Add this useEffect to watch for login success ---
  // --- 4. Add this useEffect to watch for login success (FIXED) ---
  useEffect(() => {
    // Check if USER OBJECT EXISTS
    if (user && officeSessionId.current) {
      // We don't need to read the token.
      // The browser will send the httpOnly cookie automatically.

      // --- THIS IS THE FIX ---
      // We just make a POST request with an empty body.
      apiClient
        .post(`/auth/complete-login/${officeSessionId.current}`)
        .then(() => {
          // Show success message
          setOfficeLoginSuccess(true);
        })
        .catch((err) => {
          console.error('Failed to complete office login:', err);
        });
      // --- END OF FIX ---

      officeSessionId.current = null;
    }
    // This is the NORMAL login flow
    else if (user && !officeLoginSuccess) {
      navigate('/dashboard');
    }
  }, [user, navigate, officeLoginSuccess]);

  // --- 5. Add this render logic at the top of your return() ---
  if (officeLoginSuccess) {
    return (
      // You can style this better using your existing layout
      <Box sx={{ p: 4, textAlign: 'center' }}>
        <Alert severity='success'>ورود با موفقیت انجام شد!</Alert>
        <Typography variant='h6' sx={{ mt: 2 }}>
          می‌توانید این پنجره را ببندید و به Microsoft Word بازگردید.
        </Typography>
        <Typography>افزونه Word به طور خودکار وارد خواهد شد.</Typography>
      </Box>
    );
  }

  const onSubmit: SubmitHandler<LoginFormInputs> = (data) => {
    dispatch(loginUser(data));
  };

  const handleGoogleLogin = () => {
    // Get the base URL for the API
    const baseUrl =
      import.meta.env.VITE_API_BASE_URL || 'https://localhost:5000';
    // Base URL for the auth endpoint
    let googleLoginUrl = `${baseUrl}/api/v1/auth/google`;

    // Check if we have an office session ID stored in our ref
    if (officeSessionId.current) {
      // If yes, append it to the URL so the backend can track it
      googleLoginUrl += `?session_id=${officeSessionId.current}`;
    }

    // Redirect the user
    window.location.href = googleLoginUrl;
  };

  const handleGitHubLogin = () => {
    // Get the base URL for the API
    const baseUrl =
      import.meta.env.VITE_API_BASE_URL || 'https://localhost:5000';
    // Base URL for the auth endpoint
    let githubLoginUrl = `${baseUrl}/api/v1/auth/github`;

    // Check if we have an office session ID stored in our ref
    if (officeSessionId.current) {
      // If yes, append it to the URL so the backend can track it
      githubLoginUrl += `?session_id=${officeSessionId.current}`;
    }

    // Redirect the user
    window.location.href = githubLoginUrl;
  };

  return (
    <Container sx={{ mb: 2 }}>
      <Grid
        container
        component='main'
        sx={{ width: '100%', direction: 'rtl', mx: 'auto' }}
      >
        {/* Image Grid Item - hidden on extra-small screens */}
        <Grid
          size={{ xs: 0, sm: 4, md: 6 }}
          sx={{
            backgroundImage: `url(${loginImage})`,
            backgroundRepeat: 'no-repeat',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        {/* Form Grid Item */}
        <Grid
          size={{ xs: 12, sm: 8, md: 6 }}
          component={Paper}
          elevation={6}
          square
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'background.default',
          }}
        >
          <Box
            sx={{
              my: 8,
              mx: 4,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              padding: 4,
              borderRadius: 2,
              boxShadow: '0 10px 30px rgba(0,0,0,0.1)',
              transition: 'transform 0.3s ease',
              '&:hover': {
                transform: 'translateY(-5px)',
              },
              maxWidth: 450,
            }}
          >
            <Avatar
              sx={{ m: 1, bgcolor: 'secondary.main', width: 60, height: 60 }}
            >
              <Person sx={{ fontSize: 36, color: 'white' }} />
            </Avatar>
            <Typography
              component='h1'
              variant={isMobile ? 'h5' : 'h4'}
              sx={{
                marginBottom: 3,
                fontWeight: 'bold',
                background: 'linear-gradient(45deg, #2196F3 20%, #21CBF3 90%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textAlign: 'center',
              }}
            >
              ورود به حساب کاربری
            </Typography>
            <Box
              component='form'
              noValidate
              sx={{ mt: 1, width: '100%' }}
              onSubmit={handleSubmit(onSubmit)}
            >
              {error && (
                <Alert severity='error' sx={{ width: '100%', mb: 2 }}>
                  {error}
                </Alert>
              )}
              <TextField
                variant='outlined'
                margin='normal'
                required
                fullWidth
                id='email'
                label='پست الکترونیک'
                autoComplete='email'
                autoFocus
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position='start'>
                        <Email />
                      </InputAdornment>
                    ),
                  },
                }}
                sx={{
                  borderRadius: 30,
                  '& .MuiInputBase-input': {
                    direction: 'rtl',
                    textAlign: 'right',
                  },
                }} // Apply border radius here
                {...register('email', { required: 'ایمیل الزامی است' })}
                error={!!errors.email}
                helperText={errors.email?.message}
              />
              <TextField
                variant='outlined'
                margin='normal'
                required
                fullWidth
                label='رمز عبور'
                type={showPassword ? 'text' : 'password'}
                id='password'
                autoComplete='current-password'
                slotProps={{
                  input: {
                    startAdornment: (
                      <InputAdornment position='start'>
                        <Lock />
                      </InputAdornment>
                    ),

                    endAdornment: (
                      <InputAdornment position='end'>
                        <IconButton
                          aria-label='toggle password visibility'
                          onClick={handleClickShowPassword}
                          edge='end'
                        >
                          {showPassword ? <Visibility /> : <VisibilityOff />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  },
                }}
                sx={{
                  borderRadius: 30,
                  '& .MuiInputBase-input': {
                    direction: 'rtl',
                    textAlign: 'right',
                  },
                }} // Apply border radius here
                {...register('password', { required: 'رمز عبور الزامی است' })}
                error={!!errors.password}
                helperText={errors.password?.message}
              />
              <Button
                type='submit'
                fullWidth
                variant='contained'
                loading={isLoading}
                disabled={isLoading}
                startIcon={isLoading ? <CircularProgress size={20} /> : null}
                sx={{
                  mt: 3,
                  mb: 2,
                  py: 1.5,
                  borderRadius: 30,
                  background:
                    'linear-gradient(45deg, #2196F3 30%, #21CBF3 90%)',
                  color: 'white',
                  fontWeight: 'bold',
                  transition: 'all 0.3s ease',
                  '&:hover': {
                    transform: 'scale(1.02)',
                    boxShadow: '0 5px 15px rgba(33, 203, 243, 0.4)',
                  },
                }}
              >
                ورود
              </Button>
              <Divider sx={{ my: 2, width: '100%' }}>
                <Typography variant='body2' sx={{ color: 'text.secondary' }}>
                  یا
                </Typography>
              </Divider>
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
                <Button
                  fullWidth
                  variant='outlined'
                  startIcon={<Google />}
                  onClick={handleGoogleLogin}
                  sx={{
                    py: 1.5,
                    borderRadius: 30,
                    borderColor: '#df0202',
                    color: 'text.primary',
                    '&:hover': {
                      borderColor: '#df0202',
                      backgroundColor: '#df0202',
                      color: 'white',
                    },
                  }}
                >
                  ورود با گوگل
                </Button>
                <Button
                  fullWidth
                  variant='outlined'
                  startIcon={<GitHub />}
                  onClick={handleGitHubLogin}
                  sx={{
                    py: 1.5,
                    borderRadius: 30,
                    borderColor: 'grey.400',
                    color: 'text.primary',
                    '&:hover': {
                      borderColor: '#333',
                      backgroundColor: '#151515',
                      color: 'white',
                    },
                  }}
                >
                  ورود با گیت‌هاب
                </Button>
              </Box>
              <Grid container sx={{ mt: 3 }}>
                <Grid size={{ xs: 12 }}>
                  <Typography variant='body2' sx={{ cursor: 'pointer', mb: 2 }}>
                    فراموشی رمز عبور؟
                    <Link
                      to='/forgot-password'
                      style={{
                        textDecoration: 'none',
                        color: 'inherit',
                        fontWeight: 'bold',
                        marginRight: '8px',
                      }}
                    >
                      کلیک کنید
                    </Link>
                  </Typography>
                </Grid>
                <Grid size={{ xs: 12 }}>
                  <Typography variant='body2' sx={{ cursor: 'pointer' }}>
                    حساب کاربری ندارید؟
                    <Link
                      to='/register'
                      style={{
                        textDecoration: 'none',
                        color: 'inherit',
                        fontWeight: 'bold',
                        marginRight: '8px',
                      }}
                    >
                      ثبت نام کنید
                    </Link>
                  </Typography>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
};

export default LoginPage;
